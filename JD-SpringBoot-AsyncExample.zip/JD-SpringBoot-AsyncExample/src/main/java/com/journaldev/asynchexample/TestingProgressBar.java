package com.journaldev.asynchexample;

import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class TestingProgressBar {
 
	
	public static void main(String args[]) throws IOException {
		 
		ProcessBuilder pb = new ProcessBuilder("C:\\Program Files\\ffmpeg\\bin\\ffmpeg","-i","C:\\Users\\10900\\Videos\\1280.wmv",
	    		"-c:v libx264 -crf 19 -strict experimental","C:\\Users\\10900\\Videos\\1280_wmv_9_.mp4");
		
		 
			final Process p = pb.start();
		 
		
		    new Thread() {
			public void run() {
			Scanner sc = new Scanner(p.getErrorStream());
			
			Pattern durPattern = Pattern.compile("(?<=Duration: )[^,]*");
			System.out.println("durPattern  "+"              "+durPattern);
			String dur = sc.findWithinHorizon(durPattern, 0);
			if (dur == null)
			throw new RuntimeException("Could not parse duration.");
			String[] hms = dur.split(":");
			System.out.println("duration array size------------- "+hms.length);
			double totalSecs = Integer.parseInt(hms[0]) * 3600
			+ Integer.parseInt(hms[1]) *   60
			+ Double.parseDouble(hms[2]);
			
			System.out.println("Total duration: " + totalSecs + " seconds.");

			// Find time as long as possible.
			String rx = "(?<=time= )[\\d:.]*";
			
			Pattern timePattern = Pattern.compile(rx);
			System.out.println("timepattern     "+"            "+timePattern);
			
			System.out.println("time duration--------------- "+sc.findWithinHorizon(timePattern, 0));
			String match; 
			double processedSecs;
			
			while (null != (match = sc.findWithinHorizon(timePattern, 0))) {
				System.out.println("progess while------------------ ");
				
			hms = match.split(":");
			processedSecs = Integer.parseInt(hms[0]) * 3600
			+ Integer.parseInt(hms[1]) *   60
			+ Double.parseDouble(hms[2]);
			System.out.println("Processed secs: " + processedSecs);
			double progress = processedSecs / totalSecs;
			System.out.printf("Progress: %.2f%%%n", progress * 100);
			}
			
			
			
			}
		}.start();
	} 
}
