package com.journaldev.asynchexample;

import java.io.*;
import java.util.Scanner;
import java.util.regex.Pattern;

import net.bramp.ffmpeg.FFmpeg;
import net.bramp.ffmpeg.FFmpegExecutor;
import net.bramp.ffmpeg.FFprobe;
import net.bramp.ffmpeg.builder.FFmpegBuilder;
import net.bramp.ffmpeg.progress.Progress;
import net.bramp.ffmpeg.progress.ProgressListener;

public class TestProgress {
  public static void main(String[] args) throws IOException {
	  
	 String cd = "C:\\Program Files\\ffmpeg\\bin\\ffmpeg -i C:\\Users\\10900\\Videos\\1280.wmv  "
      		+ "-c:v libx264 -crf 19 -strict experimental  C:\\Users\\10900\\Videos\\1280_wmv_.mp4";

    ProcessBuilder pb = new ProcessBuilder("C:\\Program Files\\ffmpeg\\bin\\ffmpeg","-i","C:\\Users\\10900\\Videos\\1280.wmv",
    		"-c:v libx264 -crf 19 -strict experimental","C:\\Users\\10900\\Videos\\1280_wmv_2_.mp4");
    
    final Process p = pb.start();

    new Thread() {
      public void run() {

        Scanner sc = new Scanner(p.getErrorStream());

        // Find duration
        Pattern durPattern = Pattern.compile("(?<=Duration: )[^,]*");
        String dur = sc.findWithinHorizon(durPattern, 0);
        if (dur == null)
          throw new RuntimeException("Could not parse duration.");
        String[] hms = dur.split(":");
        double totalSecs = Integer.parseInt(hms[0]) * 3600
                         + Integer.parseInt(hms[1]) *   60
                         + Double.parseDouble(hms[2]);
        System.out.println("Total duration: " + totalSecs + " seconds.");

        // Find time as long as possible.
        Pattern timePattern = Pattern.compile("(?<=time=)[\\d:.]*");
        System.out.println("TIME DURATION------------ "+sc.findWithinHorizon(durPattern, 0));
        String match;
        while (null != (match = sc.findWithinHorizon(timePattern, 0))) {
        	System.out.println("inside the whilw of the============================");
          double progress = Double.parseDouble(match) / totalSecs;
          System.out.printf("Progress: %.2f%%%n", progress * 100);
        }
      }
    }.start();

  }
	  
	  
	 
	    
}