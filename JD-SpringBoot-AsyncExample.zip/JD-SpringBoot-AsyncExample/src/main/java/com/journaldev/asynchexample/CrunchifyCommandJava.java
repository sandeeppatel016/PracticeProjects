package com.journaldev.asynchexample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.media.MediaPlayer;
import android.net.Uri;
 
/**
 * @author Crunchify.com
 * 
 */
 
public class CrunchifyCommandJava {
	public printOutput getStreamWrapper(InputStream is, String type) {
		return new printOutput(is, type);
	}
 
	public static void main(String[] args) {
        
		Runtime rt = Runtime.getRuntime();
		CrunchifyCommandJava rte = new CrunchifyCommandJava();
		printOutput errorReported, outputMessage;
        String cd = "C:\\Program Files\\ffmpeg\\bin\\ffmpeg -i C:\\Users\\10900\\Videos\\1280.wmv  "
        		+ "-c:v libx264 -crf 19 -strict experimental  C:\\Users\\10900\\Videos\\1280_wmv_26.mp4";

		try {
			Process proc = rt.exec(cd);
			// Process proc = rt.exec("mkdir /Users/<username>/Desktop/test1");
			// Process proc = rt.exec("ping https://crunchify.com");
			errorReported = rte.getStreamWrapper(proc.getErrorStream(), "ERROR");
			outputMessage = rte.getStreamWrapper(proc.getInputStream(), "OUTPUT");
			errorReported.start();
			outputMessage.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
 
	}
 
	private class printOutput extends Thread {
		InputStream is = null;
		boolean status = false;
		printOutput(InputStream is, String type) {
			this.is = is;
		}
 
		public void run() {
			String s = null;
			try {
				BufferedReader br = new BufferedReader(
						new InputStreamReader(is));
				while ((s = br.readLine()) != null) {
					//System.out.println("messages----------------- "+      s);
					//getProgress(s);
					status = true;
					onProgress(s);
				}
			} catch (IOException ioe) {
				ioe.printStackTrace();
			}
		}
	}
	
	 
	
	long videoLengthInMillis;
	Pattern durationPattern = Pattern.compile("Duration: ([\\d\\w:]{8}[\\w.][\\d]+)");
	Pattern timePattern = Pattern.compile("time=([\\d\\w:]{8}[\\w.][\\d]+)");

	public void onProgress(String message) {
	        if (message.contains("Duration")){
	            videoLengthInMillis += getTimeInMillis(message, durationPattern);
	        }else if (message.contains("speed")) {
	            long currentTime = getTimeInMillis(message, timePattern);
	            long percent = 100 * currentTime/videoLengthInMillis;
	         System.out.println("currentTime here-----> " + currentTime + "Percentage completed--- % -> " + percent);
	            if (percent < 99){
	               // progressDialog.setProgress((int) percent);
	            	System.out.println("VIDEO CONVERSION IS IN PROGRESS---------");
	            }else {
	            	System.out.println("CONGRATULATIONS UR VIDEO IS CONVERTED!!!!!!---------");
	            }
	        }
	    }

	private Long getTimeInMillis(String message, Pattern pattern){
	        Matcher matcher = pattern.matcher(message);
	        matcher.find();
	        String time = String.valueOf(matcher.group(1));
	        String[] arrayTime = time.split("[:.]");
	    System.out.println("time: " + time);
	    
	        return TimeUnit.HOURS.toMillis(Long.parseLong(arrayTime[0]))
	                + TimeUnit.MINUTES.toMillis(Long.parseLong(arrayTime[1]))
	                + TimeUnit.SECONDS.toMillis(Long.parseLong(arrayTime[2]))
	                + Long.parseLong(arrayTime[3]);
	    }
	
	
	
	
	
	
	
	/*long videoLengthInSec;

	private void getVideoLength() {
		String basePath = "C:\\Users\\10900\\Videos\\1280.wmv";
		
	 
	     MediaPlayer mp = MediaPlayer.create(MainActivity.this, Uri.parse(basePath + "input.mp4"));
	                    videoLengthInSec = TimeUnit.MILLISECONDS.toSeconds(mp.getDuration());
	                    mp.release();
	                  System.out.println( "onStart: VideoLeng -> " + videoLengthInSec);
	}

	Pattern pattern = Pattern.compile("time=([\\d\\w:]+)");
	private long getProgress(String message) {
	        if (message.contains("speed")) {
	            Matcher matcher = pattern.matcher(message);
	            matcher.find();
	            String tempTime = String.valueOf(matcher.group(1));
	            System.out.println("getProgress: tempTime " + tempTime);
	            String[] arrayTime = tempTime.split("[:|.]");
	            long currentTime =
	                    TimeUnit.HOURS.toMillis(Long.parseLong(arrayTime[0]))
	                            + TimeUnit.MINUTES.toMillis(Long.parseLong(arrayTime[1]))
	                            + TimeUnit.SECONDS.toMillis(Long.parseLong(arrayTime[2]))
	                            + Long.parseLong(arrayTime[3]);

	            long percent = 100 * currentTime/videoLengthInSec;

System.out.println( "currentTime -> " + currentTime + "s % -> " + percent);

	            return percent;
	        }
	        return 0;
	    }*/
}