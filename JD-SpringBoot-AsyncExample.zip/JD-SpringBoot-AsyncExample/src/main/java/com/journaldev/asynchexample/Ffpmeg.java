package com.journaldev.asynchexample;

import java.io.IOException;

public class Ffpmeg {

	public static void main(String args[]) throws InterruptedException {
		String cmd = "ffmpeg -i C:\\Users\\10900\\Pictures\\SampleVideo -s 1920x1080 -c:a copy C:\\Users\\10900\\Pictures\\Video2.flv";
        String cm = "C:\\Program Files\\ffmpeg\\bin\\ffmpeg -i C:\\Users\\10900\\Videos\\1280.avi  C:\\Users\\10900\\Videos\\1280_avi_1.mp4";
		try {
			Process p = Runtime.getRuntime().exec(cm);
			System.out.println("ffpmeg windows-----------------  "+"         "+p.getOutputStream().toString());
            p.waitFor();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
