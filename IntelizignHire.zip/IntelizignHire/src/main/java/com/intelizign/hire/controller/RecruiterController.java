package com.intelizign.hire.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.intelizign.hire.model.EmployeesAuthentication;
import com.intelizign.hire.requestmodel.AddCandidateRequest;
import com.intelizign.hire.services.EmployeesAuthServices;

@RestController
@RequestMapping("/recruiter/v1")
public class RecruiterController {

	public static final Logger logger = Logger.getLogger(EmployeesAuthController.class);
	public static final String TOKEN_TYPE = "bearer";
	public static final boolean REFRESH_TOKEN = false;
	public static final String CV_LOCATION = "C:\\Users\\10900\\Desktop\\Cv";
	public static final String CV_CONTENT = "application/pdf";

	@Autowired
	EmployeesAuthServices empAuthServices;

	@RequestMapping(value = "/createCandidate", method = RequestMethod.POST, consumes = { "multipart/form-data" })
	public @ResponseBody Map<Object, Object> addCandidate(@RequestParam("candidate") String candidate,
			@RequestParam("file") MultipartFile file, @RequestHeader HttpHeaders headers) {
		Map<Object, Object> status = new HashMap<Object, Object>();
		Map<String, String> headerMap = null;
		boolean addstatus = false;
		try {
			headerMap = headers.toSingleValueMap();
			if (headerMap != null) {
				String accessToken = headerMap.get("access_token");
				EmployeesAuthentication valid = empAuthServices.employeesAccessTokenValidation(accessToken);
				
				if (valid != null && valid.getAuthorization().equals("RECRUITER")) {
					AddCandidateRequest candidateObj = new ObjectMapper().readValue(candidate,AddCandidateRequest.class);
                    boolean uniquecheck = empAuthServices.candidateemailmobileCheck(candidateObj.getEmail(), candidateObj.getPhone());
                    
                    if(!uniquecheck) {
					if (!file.isEmpty() && file.getContentType().equals(CV_CONTENT)) {
						try {
							byte[] bytes = file.getBytes();
							String filename = CV_LOCATION + File.separator + file.getOriginalFilename() + "_ID_" +
									candidateObj.getPhone()  ;
							File serverFile = new File(filename);
							BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
							stream.write(bytes);
							stream.close();
							logger.info("Server File Location=" + serverFile.getAbsolutePath());

							addstatus = empAuthServices.addCandidate(valid, candidateObj, filename, CV_LOCATION);
							if (addstatus) {
								status.put("status", "201: Created!");
								status.put("message", "Candidate added !");
							} else {
								status.put("status", "500: UnSuccessfull");
								status.put("message", "Server Error !");
							}

						} catch (Exception e) {
							e.printStackTrace();
						}
					}else {
						status.put("status", "415: Not Supported Media Type");
						status.put("message", "File Content should be .pdf !");
					}
                    }else {
                    	status.put("status", "409: Conflict");
    					status.put("message", "Email/Phone already exist !");
                    }
				} else {
					status.put("status", "401: UnAuthorized");
					status.put("message", "Access Token is Invalid !");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "500: UnSuccessfull");
			status.put("message", "Server Error !");
		}
		return status;
	}
	
	 
}
