package com.intelizign.hire.util;

import java.security.SecureRandom;

public class AuthorizationTokenGeneratorImpl implements AuthorizationTokenGenerator {

	@Override
	public String generateAuthToken() throws Exception {
		SecureRandom rnd = new SecureRandom();
		StringBuilder accessToken = new StringBuilder(TOKENSIZE);

		for (int i = 0; i < TOKENSIZE; i++) {
			accessToken.append(BASECODE.charAt(rnd.nextInt(BASECODE.length())));
		}
		return accessToken.toString();
	}

	@Override
	public String generatePassword(String employeeId, String name) throws Exception {
		StringBuilder password = new StringBuilder();
        return password.append(name).append("@").append(employeeId).toString();
	}
}