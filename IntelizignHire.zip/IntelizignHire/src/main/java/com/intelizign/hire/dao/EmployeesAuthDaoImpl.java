package com.intelizign.hire.dao;

import javax.persistence.Column;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.intelizign.hire.model.Admin;
import com.intelizign.hire.model.AdminAuthentication;
import com.intelizign.hire.model.Candidate;
import com.intelizign.hire.model.CandidateCV;
import com.intelizign.hire.model.Employee;
import com.intelizign.hire.model.EmployeeBankInfo;
import com.intelizign.hire.model.EmployeePersonalInfo;
import com.intelizign.hire.model.EmployeesAuthentication;
import com.intelizign.hire.requestmodel.AddCandidateRequest;
import com.intelizign.hire.requestmodel.EmployeeBankUpdateRequest;
import com.intelizign.hire.requestmodel.UpdateEmployeeRequest;
import com.intelizign.hire.services.EmployeesAuthServices;

public class EmployeesAuthDaoImpl implements EmployeesAuthDao {

	@Autowired
	SessionFactory sessionFactory;

	Session session = null;
	Transaction tx = null;

	@Override
	public Employee employeesLogin(String empid, String password) throws Exception {
		Employee user = null;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(Employee.class);
			criteria.add(Restrictions.eq("employeeId", empid));
			criteria.add(Restrictions.eq("password", password));
			System.out.println("emp login-------------------" + "         " + criteria.uniqueResult());
			user = (Employee) criteria.uniqueResult();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return user;
	}

	@Override
	public boolean generateEmployeesAuth(EmployeesAuthentication employee) throws Exception {
		boolean status = true;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(employee);

		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

	@Override
	public EmployeesAuthentication employeesAccessTokenValidation(String accessToken) throws Exception {
		EmployeesAuthentication user = null;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(EmployeesAuthentication.class);
			criteria.add(Restrictions.eq("access_token", accessToken));

			user = (EmployeesAuthentication) criteria.uniqueResult();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			tx.commit();
			session.close();
		}
		return user;
	}

	@Override
	public boolean updateEmployees(UpdateEmployeeRequest employee, EmployeesAuthentication empAuth) throws Exception {
		Employee emp = null;
		boolean status = false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			emp = (Employee) session.get(Employee.class, empAuth.getEmployee().getId());
			if (emp != null) {
				emp.setPanNo(employee.getPanNo());
				emp.setAddress(employee.getAddress());
				emp.setAdharNo(employee.getAdharNo());
				emp.setDateOfBirth(employee.getDateOfBirth());
				emp.setPhone(employee.getPhone());
				emp.setGender(employee.getGender());
				emp.setPassportNo(employee.getPassportNo());
				emp.setPassword(employee.getPassword());
				emp.setMarritalStatus(employee.getMarritalStatus());
				session.saveOrUpdate(emp);
				status = true;
			}
		} catch (Exception e) {
			status = false;
			e.printStackTrace();

		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

	@Override
	public boolean updateEmployeesBankInfo(EmployeeBankUpdateRequest employee, EmployeesAuthentication empAuth)
			throws Exception {
		Employee emp = null;
		EmployeeBankInfo empbank = new EmployeeBankInfo();

		boolean status = false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			emp = (Employee) session.get(Employee.class, empAuth.getEmployee().getId());

			Query query = null;
			query = session
					.createQuery("UPDATE EmployeeBankInfo us SET us.bankName =:bankName,  us.branchName =:branchName,  "
							+ " us.accountNumber =:accountNumber, us.accountName =:accountName, us.ifscCode =:ifscCode WHERE us.id =:id ");
			query.setParameter("bankName", employee.getBankName());
			query.setParameter("branchName", employee.getBranchName());
			query.setParameter("accountNumber", employee.getAccountNumber());
			query.setParameter("accountName", employee.getAccountName());
			query.setParameter("ifscCode", employee.getIfscCode());
			query.setParameter("id", emp.getId());

			int i = query.executeUpdate();
			System.out.println("update the child is done here----------------------" + "          " + i);
			if (i > 0) {
				status = true;
			}
			/*
			 * if(emp != null) { empbank.setAccountName(employee.getAccountName());
			 * empbank.setAccountNumber(employee.getAccountNumber());
			 * empbank.setBankName(employee.getBankName());
			 * empbank.setBranchName(employee.getBranchName());
			 * empbank.setIfscCode(employee.getIfscCode()); empbank.setEmployee(emp);
			 * 
			 * emp.setEmployeeBank(empbank); session = sessionFactory.openSession(); tx =
			 * session.beginTransaction(); session.update(emp); status = true; }
			 */
		} catch (Exception e) {
			status = false;
			e.printStackTrace();

		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

	@Override
	public boolean addCandidate(EmployeesAuthentication empauth, AddCandidateRequest candidate, String fileName,
			String fileLoc) throws Exception {
		boolean status = true;

		CandidateCV candidcv = new CandidateCV();
		candidcv.setCvFileLocation(fileLoc);
		candidcv.setCvFileName(fileName);

		Candidate candid = new Candidate();
		candid.setAddress(candidate.getAddress());

		switch (candidate.getCatagory()) {
		case "TESTING":
			candid.setCatagory(Candidate.InterviewCategory.TESTING);
			break;
		case "DEVELOPEMENT":
			candid.setCatagory(Candidate.InterviewCategory.DEVELOPEMENT);
			break;
		case "DBA":
			candid.setCatagory(Candidate.InterviewCategory.DBA);
			break;
		case "HR":
			candid.setCatagory(Candidate.InterviewCategory.HR);
			break;
		default:
			candid.setCatagory(Candidate.InterviewCategory.DEVELOPEMENT);
			break;
		}
		 
		switch (candidate.getResult()) {
		case "SELECTED":
			candid.setResult(Candidate.InterviewResult.SELECTED);
			break;
		case "REJECTED":
			candid.setResult(Candidate.InterviewResult.REJECTED);
			break;
		case "INREVIEWBYTECHNICAL":
			candid.setResult(Candidate.InterviewResult.INREVIEWBYTECHNICAL);
			break;
		case "ONHOLD":
			candid.setResult(Candidate.InterviewResult.ONHOLD);
			break;
		default:
			candid.setResult(Candidate.InterviewResult.ONHOLD);
			break;
		}
		
		switch (candidate.getStatus()) {
		case "SHORTLISTED":
			candid.setStatus(Candidate.InterviewStatus.SHORTLISTED);
			break;
		case "SHEDULED":
			candid.setStatus(Candidate.InterviewStatus.SHEDULED);
			break;
		case "ATTENDED":
			candid.setStatus(Candidate.InterviewStatus.ATTENDED);
			break;
		case "REFUSETOATTEND":
			candid.setStatus(Candidate.InterviewStatus.REFUSETOATTEND);
			break;
		default:
			candid.setStatus(Candidate.InterviewStatus.SHORTLISTED);
			break;
		}
		candid.setCurrenctOrganization(candidate.getCurrenctOrganization());
		candid.setCurrentCtc(candidate.getCurrentCtc());
		candid.setDateOfInterview(candidate.getDateOfInterview());
		candid.setDomain(candidate.getDomain());
		candid.setExpectedCtc(candidate.getExpectedCtc());
		candid.setExperience(candidate.getExperience());
		candid.setEmail(candidate.getEmail());
		candid.setRelevantExperience(candidate.getRelevantExperience());
		candid.setFirstName(candidate.getFirstName());
		candid.setGender(candidate.getGender());
		candid.setInterviewer(candidate.getInterviewer());
		candid.setInterviewLocation(candidate.getInterviewLocation());
		candid.setInterviewMode(candidate.getInterviewMode());
		candid.setKeySkills(candidate.getKeySkills());
		candid.setLastName(candidate.getLastName());
		candid.setNoticePeriod(candidate.getNoticePeriod());
		candid.setPhone(candidate.getPhone());
		candid.setQualification(candidate.getQualification());
		candid.setRecruiterId(empauth.getEmployee().getId());
		candid.setCandidatecv(candidcv);
		candidcv.setCandidate(candid);
		
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(candid);

		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

	@Override
	public boolean candidateemailmobileCheck(String email, String mobile) throws Exception {
		Query query = null;
		boolean status = false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			query = session.createQuery("FROM Candidate ad WHERE ad.email=:email OR ad.phone=:phone ");
			query.setParameter("email", email);
			query.setParameter("phone", mobile);
			if (query.uniqueResult() != null) {
				status = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

}
