package com.intelizign.hire.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.intelizign.hire.dao.EmployeesAuthDao;
import com.intelizign.hire.model.Employee;
import com.intelizign.hire.model.EmployeesAuthentication;
import com.intelizign.hire.requestmodel.AddCandidateRequest;
import com.intelizign.hire.requestmodel.EmployeeBankUpdateRequest;
import com.intelizign.hire.requestmodel.UpdateEmployeeRequest;

public class EmployeesAuthServicesImpl implements EmployeesAuthServices{

	@Autowired
	EmployeesAuthDao empAuthDao;
	
	@Override
	public Employee employeesLogin(String empid, String password) throws Exception {
		return empAuthDao.employeesLogin(empid, password);
	}

	@Override
	public boolean generateEmployeesAuth(EmployeesAuthentication employee) throws Exception {
		return empAuthDao.generateEmployeesAuth(employee);
	}

	@Override
	public EmployeesAuthentication employeesAccessTokenValidation(String accessToken) throws Exception {
		return empAuthDao.employeesAccessTokenValidation(accessToken);
	}

	 
	@Override
	public boolean updateEmployees(UpdateEmployeeRequest employee, EmployeesAuthentication empAuth) throws Exception {
		return empAuthDao.updateEmployees(employee, empAuth);
	}

	@Override
	public boolean updateEmployeesBankInfo(EmployeeBankUpdateRequest employee, EmployeesAuthentication empAuth)
			throws Exception {
		return empAuthDao.updateEmployeesBankInfo(employee, empAuth);
	}
 
	@Override
	public boolean addCandidate(EmployeesAuthentication empauth, AddCandidateRequest candidate, String fileName,
			String fileLoc) throws Exception {
		return empAuthDao.addCandidate(empauth, candidate, fileName, fileLoc);
	}

	@Override
	public boolean candidateemailmobileCheck(String email, String mobile) throws Exception {
		return empAuthDao.candidateemailmobileCheck(email, mobile);
	}

}
