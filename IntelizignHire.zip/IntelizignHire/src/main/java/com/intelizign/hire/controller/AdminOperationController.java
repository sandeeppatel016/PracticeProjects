package com.intelizign.hire.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.intelizign.hire.model.AdminAuthentication;
import com.intelizign.hire.model.Employee;
import com.intelizign.hire.model.EmployeeBankInfo;
import com.intelizign.hire.model.EmployeePersonalInfo;
import com.intelizign.hire.model.Jobs;
import com.intelizign.hire.model.Employee.EmployeeRole;
import com.intelizign.hire.requestmodel.AddEmployeeRequest;
import com.intelizign.hire.requestmodel.AddJobsRequest;
import com.intelizign.hire.services.AdminServices;
import com.intelizign.hire.util.AuthorizationTokenGenerator;
import com.intelizign.hire.util.EmailNotificationService;

@RestController
@RequestMapping("/admin/v1")
public class AdminOperationController {

	@Autowired
	AdminServices adminServices;

	@Autowired
	AuthorizationTokenGenerator authServices;

	@Autowired
	EmailNotificationService emailServices;

	public static final Logger logger = Logger.getLogger(AdminOperationController.class);
	public static final String TOKEN_TYPE = "bearer";
	public static final boolean REFRESH_TOKEN = false;

	@RequestMapping(value = "/addEmployees", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<Object, Object> addEmployee(@RequestBody AddEmployeeRequest employee,
			@RequestHeader HttpHeaders headers) {
		Map<Object, Object> status = new HashMap<Object, Object>();
		Map<String, String> headerMap = null;
		Employee emp = new Employee();
		try {
			headerMap = headers.toSingleValueMap();
			if (headerMap != null) {
				String accessToken = headerMap.get("access_token");
				AdminAuthentication adauth = adminServices.adminAccessTokenValidation(accessToken);

				if (adauth != null) {

					emp.setFirstName(employee.getFirstName());
					emp.setLastName(employee.getLastName());
					emp.setEmployeeId(String.valueOf(employee.getEmployee_id()));
					emp.setEmployeeEmail(employee.getEmployeeEmail());
					emp.setDepartment(employee.getDepartment());
					emp.setDesignation(employee.getDesignation());
					emp.setLocation(employee.getLocation());

					String password = authServices.generatePassword(employee.getEmployee_id(), employee.getFirstName());
					emp.setPassword(password);

					EmployeeBankInfo empBank = new EmployeeBankInfo();
					empBank.setEmployee(emp);
					EmployeePersonalInfo empPer = new EmployeePersonalInfo();
					empPer.setEmployee(emp);

					emp.setEmployeeBank(empBank);
					emp.setEmployeeInfo(empPer);

					if (employee.getEmployeeRole().equalsIgnoreCase("RECRUITER")) {
						emp.setEmployee_role(EmployeeRole.RECRUITER);
					} else {
						emp.setEmployee_role(EmployeeRole.EMPLOYEE);
					}
					boolean empstatus = false;
					boolean checkStatus = adminServices.employeeEmailIdCheck(employee.getEmployeeEmail(),
							employee.getEmployee_id());
					if (!checkStatus) {
						empstatus = adminServices.addEmployees(emp);
						if (empstatus) {
							// this part of the code will work if the GMAIL working on your environment
							/*
							 * boolean emailstatus =
							 * emailServices.sendEmailNotification(employee.getPersonalEmail(),
							 * employee.getFirstName(), employee.getEmployeeEmail(),
							 * String.valueOf(employee.getEmployee_id()), password);
							 */
							boolean emailstatus = true;
							if (emailstatus) {
								status.put("status", "201: Created!");
								status.put("message", "Employee added, Credentials sends to their emails");
							}
						} else {
							status.put("status", "500: Server Error");
							status.put("message", "Employee not added");
						}
					} else {
						status.put("status", "409: Conflict!");
						status.put("message", "Employee id, or email already exist!");
					}

				} else {
					status.put("status", "401: UnAuthorized");
					status.put("message", "Access Token is invalid");
				}
			} else {
				status.put("status", "400: Bad Request");
				status.put("message", "Header's value not specified");
			}

		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "500: Server Error");
			status.put("message", "Server Error !");
		}
		return status;

	}

	@RequestMapping(value = "/addJobs", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<Object, Object> addJobs(@RequestBody AddJobsRequest job,
			@RequestHeader HttpHeaders headers) {
		Map<Object, Object> status = new HashMap<Object, Object>();
		Map<String, String> headerMap = null;
		Jobs jobs = new Jobs();
		boolean addstatus = false;
		try {
			headerMap = headers.toSingleValueMap();
			if (headerMap != null) {
				String accessToken = headerMap.get("access_token");
				AdminAuthentication valid = adminServices.adminAccessTokenValidation(accessToken);
				if (valid != null) {

					jobs.setCatagory(job.getCatagory());
					jobs.setComapny(job.getComapny());
					jobs.setCreatedAt(job.getCreatedAt());
					jobs.setOfferedCtc(job.getOfferedCtc());
					jobs.setDomain(job.getDomain());
					jobs.setExperience(job.getExperience());
					jobs.setTitle(job.getTitle());
					jobs.setLocation(job.getLocation());
					jobs.setNoticePeriod(job.getNoticePeriod());
					jobs.setQualification(job.getQualification());
					jobs.setSkills(job.getSkills());
					jobs.setVacancies(job.getVacancies());
					jobs.setAdmin(valid.getAdmin());

					addstatus = adminServices.addJobs(jobs);

					if (addstatus) {
						status.put("status", "201: Created!");
						status.put("message", "Employee added, Credentials sends to their emails");
					} else {
						status.put("status", "500: Server Error");
						status.put("message", "Employee not added");
					}
				} else {
					status.put("status", "401: UnAuthorized");
					status.put("message", "Access Token is invalid");
				}

			} else {
				status.put("status", "400: Bad Request");
				status.put("message", "Header's value not specified");
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "500: Server Error");
			status.put("message", "Server Error !");
		}
		return status;
	}

}
