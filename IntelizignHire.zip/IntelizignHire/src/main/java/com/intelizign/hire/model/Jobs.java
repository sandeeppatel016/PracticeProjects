package com.intelizign.hire.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "jobs")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Jobs implements Serializable {

	private static final long serialVersionUID = 9121527823507397954L;

	/**
	 * 
	 */

	@Id
	@GeneratedValue
	@Column(name = "id")
	private long id;
 
	// @JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
	private Date CreatedAt;

	@Column(name = "catagory")
	private String catagory;

	@Column(name = "title")
	private String title;

	@Column(name = "skills")
	private String skills;

	@Column(name = "experience")
	private int experience;

	@Column(name = "comapny")
	private String comapny;

	@Column(name = "offered_ctc")
	private long offeredCtc;

	@Column(name = "notice_period")
	private int noticePeriod;

	@Column(name = "domain")
	private String domain;

	@Column(name = "location")
	private String location;

	@Column(name = "qualification")
	private String qualification;

	@Column(name = "no_of_vacancies")
	private int vacancies;

	@ManyToOne
	private Admin admin;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return CreatedAt;
	}

	public void setCreatedAt(Date createdAt) {
		CreatedAt = createdAt;
	}

	public String getCatagory() {
		return catagory;
	}

	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getComapny() {
		return comapny;
	}

	public void setComapny(String comapny) {
		this.comapny = comapny;
	}

	public long getOfferedCtc() {
		return offeredCtc;
	}

	public void setOfferedCtc(long offeredCtc) {
		this.offeredCtc = offeredCtc;
	}

	public int getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(int noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public int getVacancies() {
		return vacancies;
	}

	public void setVacancies(int vacancies) {
		this.vacancies = vacancies;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

}
