package com.intelizign.hire.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.intelizign.hire.dao.AdminDao;
import com.intelizign.hire.model.Admin;
import com.intelizign.hire.model.AdminAuthentication;
import com.intelizign.hire.model.Employee;
import com.intelizign.hire.model.Jobs;

public class AdminServicesImpl implements AdminServices {

	@Autowired
	AdminDao adminDao;

	@Override
	public boolean adminRegistration(Admin admin) throws Exception {
		return adminDao.adminRegistration(admin);
	}

	@Override
	public boolean emailUsernameCheck(String email, String username) throws Exception {
		return adminDao.emailUsernameCheck(email, username);
	}

	@Override
	public Admin adminLogin(String emailusername, String username) throws Exception {
		return adminDao.adminLogin(emailusername, username);
	}

	@Override
	public boolean generateUserAuth(AdminAuthentication admin) throws Exception {
		return adminDao.generateUserAuth(admin);
	}

	@Override
	public boolean logoutAdmin(String accessToken) throws Exception {
		return adminDao.logoutAdmin(accessToken);
	}

	@Override
	public AdminAuthentication adminAccessTokenValidation(String accessToken) throws Exception {
		return adminDao.adminAccessTokenValidation(accessToken);
	}

	@Override
	public boolean addEmployees(Employee employee) throws Exception {
		return adminDao.addEmployees(employee);
	}

	@Override
	public boolean employeeEmailIdCheck(String email, String empId) throws Exception {
		return adminDao.employeeEmailIdCheck(email, empId);
	}

	@Override
	public boolean addJobs(Jobs job) throws Exception {
		return adminDao.addJobs(job);
	}

}
