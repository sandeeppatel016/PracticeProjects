package com.intelizign.hire.util;

public interface AuthorizationTokenGenerator {
	public static final String BASECODE = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	public static final int TOKENSIZE = 300;
	public static final String TOKEN_TYPE ="bearer";
	public static final boolean REFRESH_TOKEN = false;
	
   public String generateAuthToken() throws Exception;
   public String generatePassword(String employeeId, String name) throws Exception;

}
