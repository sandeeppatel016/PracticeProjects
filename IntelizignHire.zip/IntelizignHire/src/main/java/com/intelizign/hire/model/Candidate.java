package com.intelizign.hire.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "candidate")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Candidate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6084917341220396147L;

	public enum InterviewCategory {
		TESTING, DEVELOPEMENT, DBA, HR
	}
	
	public enum InterviewResult {
		SELECTED, REJECTED, INREVIEWBYTECHNICAL, ONHOLD
	}

	public enum InterviewStatus {
		SHORTLISTED, SHEDULED, ATTENDED, REFUSETOATTEND
	}
	
	@Id
	@GeneratedValue
	@Column(name = "id")
	private long id;

	@Column(name = "recruiter_id")
	private long recruiterId;
	
	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "qualification")
	private String qualification;

	@Column(name = "email")
	private String email;

	@Column(name = "phone")
	private String phone;

	@Column(name = "currenct_organization")
	private String currenctOrganization;

	@Column(name = "experience")
	private int experience;

	@Column(name = "relevant_experience")
	private int relevantExperience;

	@Column(name = "current_ctc")
	private long currentCtc;

	@Column(name = "expected_ctc")
	private long expectedCtc;

	@Column(name = "key_skills")
	private String keySkills;

	@Column(name = "domain")
	private String domain;

	@Column(name = "address")
	private String address;

	@Column(name = "gender")
	private String gender;

	@Column(name = "notice_period")
	private int noticePeriod;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_of_interview")
	private Date dateOfInterview;

	@Column(columnDefinition = "enum('TESTING', 'DEVELOPEMENT', 'DBA', 'HR')")
	@Enumerated(EnumType.STRING)
	private InterviewCategory catagory;

	@Column(columnDefinition = "enum('SELECTED', 'REJECTED', 'INREVIEWBYTECHNICAL', 'ONHOLD')")
	@Enumerated(EnumType.STRING)
	private InterviewResult result;
	
	@Column(columnDefinition = "enum('SHORTLISTED', 'SHEDULED', 'ATTENDED', 'REFUSETOATTEND')")
	@Enumerated(EnumType.STRING)
	private InterviewStatus status;
	
	@Column(name = "interview_mode")
	private String interviewMode;

	@Column(name = "interview_location")
	private String interviewLocation;

	@Column(name = "interviewer")
	private String interviewer;

	@OneToOne(mappedBy = "candidate", cascade = CascadeType.ALL)
	private CandidateCV candidatecv;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCurrenctOrganization() {
		return currenctOrganization;
	}

	public void setCurrenctOrganization(String currenctOrganization) {
		this.currenctOrganization = currenctOrganization;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getRelevantExperience() {
		return relevantExperience;
	}

	public void setRelevantExperience(int relevantExperience) {
		this.relevantExperience = relevantExperience;
	}

	public long getCurrentCtc() {
		return currentCtc;
	}

	public void setCurrentCtc(long currentCtc) {
		this.currentCtc = currentCtc;
	}

	public long getExpectedCtc() {
		return expectedCtc;
	}

	public void setExpectedCtc(long expectedCtc) {
		this.expectedCtc = expectedCtc;
	}

	public String getKeySkills() {
		return keySkills;
	}

	public void setKeySkills(String keySkills) {
		this.keySkills = keySkills;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getNoticePeriod() {
		return noticePeriod;
	}

	public void setNoticePeriod(int noticePeriod) {
		this.noticePeriod = noticePeriod;
	}

	public Date getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	public InterviewCategory getCatagory() {
		return catagory;
	}

	public void setCatagory(InterviewCategory catagory) {
		this.catagory = catagory;
	}

	public String getInterviewMode() {
		return interviewMode;
	}

	public void setInterviewMode(String interviewMode) {
		this.interviewMode = interviewMode;
	}

	public String getInterviewLocation() {
		return interviewLocation;
	}

	public void setInterviewLocation(String interviewLocation) {
		this.interviewLocation = interviewLocation;
	}

	public String getInterviewer() {
		return interviewer;
	}

	public void setInterviewer(String interviewer) {
		this.interviewer = interviewer;
	}

	public CandidateCV getCandidatecv() {
		return candidatecv;
	}

	public void setCandidatecv(CandidateCV candidatecv) {
		this.candidatecv = candidatecv;
	}

	public long getRecruiterId() {
		return recruiterId;
	}

	public void setRecruiterId(long recruiterId) {
		this.recruiterId = recruiterId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public InterviewResult getResult() {
		return result;
	}

	public void setResult(InterviewResult result) {
		this.result = result;
	}

	public InterviewStatus getStatus() {
		return status;
	}

	public void setStatus(InterviewStatus status) {
		this.status = status;
	}

	
	
}
