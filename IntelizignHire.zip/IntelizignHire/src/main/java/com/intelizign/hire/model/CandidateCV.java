package com.intelizign.hire.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "candidate_cv")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class CandidateCV implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5349329321737355210L;

	@Id
	@GeneratedValue
	@Column(name = "id")
	private long id;

	@Column(name = "cv_file_name")
	private String cvFileName;

	@Column(name = "cv_file_location")
	private String cvFileLocation;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "candidate_id")
	private Candidate candidate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCvFileName() {
		return cvFileName;
	}

	public void setCvFileName(String cvFileName) {
		this.cvFileName = cvFileName;
	}

	public String getCvFileLocation() {
		return cvFileLocation;
	}

	public void setCvFileLocation(String cvFileLocation) {
		this.cvFileLocation = cvFileLocation;
	}

	public Candidate getCandidate() {
		return candidate;
	}

	public void setCandidate(Candidate candidate) {
		this.candidate = candidate;
	}

}
