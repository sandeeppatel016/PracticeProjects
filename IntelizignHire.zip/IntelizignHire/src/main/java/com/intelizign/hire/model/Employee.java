package com.intelizign.hire.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "employee")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8519676354082809340L;

	public enum EmployeeRole {
		RECRUITER, EMPLOYEE
	}

	@Id
	@GeneratedValue
	@Column(name = "id")
	private long id;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "employee_id")
	private String employeeId;

	@Column(name = "phone")
	private String phone;

	@Column(name = "password")
	private String password;

	@Column(name = "employee_email")
	private String employeeEmail;

	@Column(name = "address")
	private String address;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_of_join")
	private Date dateOfJoin;

	@Column(name = "department")
	private String department;

	@Column(name = "location")
	private String location;

	@Column(name = "designation")
	private String designation;

	@Column(name = "gender")
	private String gender;

	@Column(name = "pan_no")
	private String panNo;

	@Column(name = "adhar_no")
	private String adharNo;

	@Column(name = "pass_port_no")
	private String passportNo;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	@Column(name = "marrital_status")
	private String marritalStatus;

	@Column(columnDefinition = "enum('RECRUITER','EMPLOYEE')")
	@Enumerated(EnumType.STRING)
	private EmployeeRole employee_role;

	@OneToOne(mappedBy = "employee", cascade = CascadeType.ALL)
	private EmployeeBankInfo employeeBank;

	@OneToOne(mappedBy = "employee", cascade = CascadeType.ALL)
	private EmployeePersonalInfo employeeInfo;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "employee_id")
	private List<EmployeesAuthentication> employeeAuth;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmployeeEmail() {
		return employeeEmail;
	}

	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDateOfJoin() {
		return dateOfJoin;
	}

	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getAdharNo() {
		return adharNo;
	}

	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMarritalStatus() {
		return marritalStatus;
	}

	public void setMarritalStatus(String marritalStatus) {
		this.marritalStatus = marritalStatus;
	}

	public EmployeeBankInfo getEmployeeBank() {
		return employeeBank;
	}

	public void setEmployeeBank(EmployeeBankInfo employeeBank) {
		this.employeeBank = employeeBank;
	}

	public EmployeePersonalInfo getEmployeeInfo() {
		return employeeInfo;
	}

	public void setEmployeeInfo(EmployeePersonalInfo employeeInfo) {
		this.employeeInfo = employeeInfo;
	}

	public EmployeeRole getEmployee_role() {
		return employee_role;
	}

	public void setEmployee_role(EmployeeRole employee_role) {
		this.employee_role = employee_role;
	}

	public List<EmployeesAuthentication> getEmployeeAuth() {
		return employeeAuth;
	}

	public void setEmployeeAuth(List<EmployeesAuthentication> employeeAuth) {
		this.employeeAuth = employeeAuth;
	}

}
