package com.intelizign.hire.dao;

import com.intelizign.hire.model.Employee;
import com.intelizign.hire.model.EmployeesAuthentication;
import com.intelizign.hire.requestmodel.AddCandidateRequest;
import com.intelizign.hire.requestmodel.EmployeeBankUpdateRequest;
import com.intelizign.hire.requestmodel.UpdateEmployeeRequest;

public interface EmployeesAuthDao {
	public Employee  employeesLogin(String empid,String password) throws Exception;
	public boolean generateEmployeesAuth(EmployeesAuthentication employee) throws Exception;
	public EmployeesAuthentication employeesAccessTokenValidation(String accessToken) throws Exception;
	public boolean updateEmployees(UpdateEmployeeRequest employee, EmployeesAuthentication empAuth) throws Exception;
	public boolean updateEmployeesBankInfo(EmployeeBankUpdateRequest employee, EmployeesAuthentication empAuth) throws Exception;
	
	public boolean addCandidate(EmployeesAuthentication empauth, AddCandidateRequest candidate, String fileName, String fileLoc) throws Exception;
	public boolean candidateemailmobileCheck(String email,String mobile) throws Exception;
}
