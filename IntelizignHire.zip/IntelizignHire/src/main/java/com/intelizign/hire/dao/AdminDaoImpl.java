package com.intelizign.hire.dao;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.intelizign.hire.model.Admin;
import com.intelizign.hire.model.AdminAuthentication;
import com.intelizign.hire.model.Employee;
import com.intelizign.hire.model.Jobs;

public class AdminDaoImpl implements AdminDao {

	@Autowired
	SessionFactory sessionFactory;

	Session session = null;
	Transaction tx = null;

	@Override
	public boolean adminRegistration(Admin admin) throws Exception {
		boolean status = true;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(admin);

		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

	@Override
	public boolean emailUsernameCheck(String email, String username) throws Exception {
		Query query = null;
		boolean status = false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			query = session.createQuery("FROM Admin ad WHERE ad.email=:email OR ad.username=:username ");
			query.setParameter("email", email);
			query.setParameter("username", username);
			if (query.uniqueResult() != null) {
				status = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}

		return status;
	}

	@Override
	public Admin adminLogin(String emailusername, String username) throws Exception {
		Admin user = null;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(Admin.class);
			criteria.add(Restrictions.eq("username", emailusername));
			criteria.add(Restrictions.eq("password", username));
			System.out.println("user login-------------------" + "         " + criteria.uniqueResult());
			user = (Admin) criteria.uniqueResult();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return user;

	}

	@Override
	public boolean generateUserAuth(AdminAuthentication admin) throws Exception {
		boolean status = true;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(admin);

		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

	@Override
	public boolean logoutAdmin(String accessToken) throws Exception {
		Query query = null;
		boolean status = false;
		try {

			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			query = session.createQuery(
					"UPDATE AdminAuthentication us SET us.access_token =:value WHERE us.access_token =:access_token ");
			query.setParameter("value", null);
			query.setParameter("access_token", accessToken);
			int i = query.executeUpdate();
			if (i > 0) {
				status = true;
			}
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}

		return status;
	}

	@Override
	public AdminAuthentication adminAccessTokenValidation(String accessToken) throws Exception {
		AdminAuthentication user = null;
		boolean status = false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			Criteria criteria = session.createCriteria(AdminAuthentication.class);
			criteria.add(Restrictions.eq("access_token", accessToken));

 			user = (AdminAuthentication) criteria.uniqueResult();
 			
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
			
		} finally {
			tx.commit();
			session.close();
		}
		return user;
	}

	@Override
	public boolean addEmployees(Employee employee) throws Exception {
		boolean status = true;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(employee);

		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

	@Override
	public boolean employeeEmailIdCheck(String email, String empId) throws Exception {
		Query query = null;
		boolean status = false;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			query = session.createQuery("FROM Employee ad WHERE ad.employeeEmail=:email OR ad.employeeId=:employeeId ");
			query.setParameter("email", email);
			query.setParameter("employeeId", empId);
			if (query.uniqueResult() != null) {
				status = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
        System.out.println("email id status for the employees---------------------"+"              "+status);
		return status;
	}

	@Override
	public boolean addJobs(Jobs job) throws Exception {
		boolean status = true;
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(job);

		} catch (Exception e) {
			status = false;
			e.printStackTrace();
		} finally {
			tx.commit();
			session.close();
		}
		return status;
	}

}
