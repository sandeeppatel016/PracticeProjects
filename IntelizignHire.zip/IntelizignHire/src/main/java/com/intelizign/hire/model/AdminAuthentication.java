package com.intelizign.hire.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "admin_auth")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class AdminAuthentication implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5142790634174434816L;

	@Id
	@GeneratedValue
	@Column(name = "id")
	private long id;

	@Type(type = "text")
	@Column(name = "access_token")
	private String access_token;

	// @JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
	private Date CreatedAt;

	@Column(name = "token_type")
	private String tokeType;

	@Column(name = "authorization")
	private String authorization;

	// @JsonIgnore
	@Column(name = "refresh_token")
	private boolean refreshToken;

	@ManyToOne
	private Admin admin;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public Date getCreatedAt() {
		return CreatedAt;
	}

	public void setCreatedAt(Date createdAt) {
		CreatedAt = createdAt;
	}

	public String getTokeType() {
		return tokeType;
	}

	public void setTokeType(String tokeType) {
		this.tokeType = tokeType;
	}

	public boolean isRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(boolean refreshToken) {
		this.refreshToken = refreshToken;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public String getAuthorization() {
		return authorization;
	}

	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}

}
