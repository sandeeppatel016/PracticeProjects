package com.intelizign.hire.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.intelizign.hire.model.Admin;
import com.intelizign.hire.model.AdminAuthentication;
import com.intelizign.hire.services.AdminServices;
import com.intelizign.hire.util.AuthorizationTokenGenerator;
  

@RestController
@RequestMapping("/admin/v1")
public class AdminAuthController {

	@Autowired
	AdminServices adminServices;

	@Autowired
	AuthorizationTokenGenerator authServices;
	
	static final Logger logger = Logger.getLogger(AdminAuthController.class);
	public static final String TOKEN_TYPE = "bearer";
	public static final String AUTHORIZATION = "ADMIN";
	public static final boolean REFRESH_TOKEN = false;

	@RequestMapping(value = "/register", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<Object, Object> addEmployee(@RequestBody Admin admin) {
		Map<Object, Object> status = new HashMap<Object, Object>();
		try {
			// check username/email exists
			boolean check_res = adminServices.emailUsernameCheck(admin.getEmail(), admin.getUsername());
			if (!check_res) {
				boolean response = adminServices.adminRegistration(admin);
				if (response) {
					status.put("status", "201: Created!");
					status.put("message", "Admin added successfull!");
				} else {
					status.put("status", "500: UnSuccessfull");
					status.put("message", "Admin Not added: Internal Server Error!");
				}
			} else {
				status.put("status", "409: Conflict");
				status.put("message", "Admin Email/Username Already Exist !");
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "500: UnSuccessfull");
			status.put("message", "Admin Not added: Internal Server Error!");
		}
		return status;

	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<Object, String> userLogin(@RequestBody Map<String, String> params) {
		Map<Object, String> status = new HashMap<Object, String>();
		AdminAuthentication response = new AdminAuthentication();
		String accessToken = null;
		boolean authStatus = false;

		try {
			if (params.get("username") != null && params.get("password") != null) {
				Admin user = adminServices.adminLogin(params.get("username"), params.get("password"));
				if (user != null) {
					if (user.getUsername().equals(params.get("username"))
							&& user.getPassword().equals(params.get("password"))) {
						System.out.println("USER EXIST........");
						try {
							accessToken = authServices.generateAuthToken();
						} catch (Exception e1) {
							e1.printStackTrace();
						}
						Timestamp timestamp = new Timestamp(System.currentTimeMillis());
						response.setAccess_token(accessToken);
						response.setCreatedAt(timestamp);
						response.setRefreshToken(REFRESH_TOKEN);
						response.setTokeType(TOKEN_TYPE);
						response.setAuthorization(AUTHORIZATION);
						response.setAdmin(user);
						authStatus = adminServices.generateUserAuth(response);
						if (authStatus) {
							status.put("access_token", response.getAccess_token());
							status.put("authorization", response.getAuthorization());
							status.put("token_type", response.getTokeType());
							return status;
						}
					}
				} else {
					status.put("status", "401: UnAuthorized");
					status.put("message", "Your Username/Password is wrong !");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "500: UnSuccessfull");
			status.put("message", "Admin Not added: Internal Server Error!");
		}
		return status;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public @ResponseBody Map<Object, String> userLogout(@RequestHeader HttpHeaders headers) {
		Map<Object, String> status = new HashMap<Object, String>();
		boolean authStatus = false;
		Map<String, String> headerMap = null;

		try {
			headerMap = headers.toSingleValueMap();
			if (headerMap != null) {
				String accessToken = headerMap.get("access_token");
				authStatus = adminServices.logoutAdmin(accessToken);
				if (authStatus) {
					status.put("status", "200: Successfull");
					status.put("message", "Logout Success !");
				} else {
					status.put("status", "500: UnSuccessfull");
					status.put("message", "Internal Server Error !");
				}
			} else {
				status.put("status", "401: UnAuthorized");
				status.put("message", "Access Token Invalid !");
			}

		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "505: UnSuccessfull");
			status.put("message", "Server Error !");
		}
		return status;
	}
}
