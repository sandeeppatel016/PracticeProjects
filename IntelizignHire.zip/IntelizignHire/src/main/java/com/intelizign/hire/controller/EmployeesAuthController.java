package com.intelizign.hire.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.intelizign.hire.model.Admin;
import com.intelizign.hire.model.AdminAuthentication;
import com.intelizign.hire.model.Employee;
import com.intelizign.hire.model.EmployeeBankInfo;
import com.intelizign.hire.model.EmployeePersonalInfo;
import com.intelizign.hire.model.Employee.EmployeeRole;
import com.intelizign.hire.requestmodel.AddEmployeeRequest;
import com.intelizign.hire.requestmodel.EmployeeBankUpdateRequest;
import com.intelizign.hire.requestmodel.UpdateEmployeeRequest;
import com.intelizign.hire.model.EmployeesAuthentication;
import com.intelizign.hire.services.EmployeesAuthServices;
import com.intelizign.hire.util.AuthorizationTokenGenerator;

@RestController
@RequestMapping("/employee/v1")
public class EmployeesAuthController {

	@Autowired
	EmployeesAuthServices empAuthServices;

	@Autowired
	AuthorizationTokenGenerator authServices;

	public static final Logger logger = Logger.getLogger(EmployeesAuthController.class);
	public static final String TOKEN_TYPE = "bearer";
	public static final boolean REFRESH_TOKEN = false;

	@RequestMapping(value = "/login", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<Object, String> userLogin(@RequestBody Map<String, String> params) {
		Map<Object, String> status = new HashMap<Object, String>();
		EmployeesAuthentication response = new EmployeesAuthentication();
		String accessToken = null;
		boolean authStatus = false;

		try {
			if (params.get("employeeId") != null && params.get("password") != null) {
				Employee user = empAuthServices.employeesLogin(params.get("employeeId"), params.get("password"));
				if (user != null) {
					if (user.getEmployeeId().equals(params.get("employeeId"))
							&& user.getPassword().equals(params.get("password"))) {
						System.out.println("USER EXIST........");
						try {
							accessToken = authServices.generateAuthToken();
						} catch (Exception e1) {
							e1.printStackTrace();
						}
						Timestamp timestamp = new Timestamp(System.currentTimeMillis());
						response.setAccess_token(accessToken);
						response.setCreatedAt(timestamp);
						response.setRefreshToken(REFRESH_TOKEN);
						response.setTokeType(TOKEN_TYPE);
						response.setEmployee(user);
						if (user.getEmployee_role().equals(EmployeeRole.EMPLOYEE)) {
							response.setAuthorization("EMPLOYEE");
						} else {
							response.setAuthorization("RECRUITER");
						}
						authStatus = empAuthServices.generateEmployeesAuth(response);
						if (authStatus) {
							status.put("access_token", response.getAccess_token());
							status.put("authorization", response.getAuthorization());
							status.put("token_type", response.getTokeType());
							return status;
						}
					}
				} else {
					status.put("status", "401 :UnAuthorized");
					status.put("message", "Your Username/Password is wrong !");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "500: UnSuccessfull");
			status.put("message", "Server Error !");
		}
		return status;
	}

	@RequestMapping(value = "/updateProfile", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<Object, Object> updateEmployeeProfile(@RequestBody UpdateEmployeeRequest employee,
			@RequestHeader HttpHeaders headers) {
		Map<Object, Object> status = new HashMap<Object, Object>();
		Map<String, String> headerMap = null;

		try {
			headerMap = headers.toSingleValueMap();
			if (headerMap != null) {
				String accessToken = headerMap.get("access_token");
				EmployeesAuthentication valid = empAuthServices.employeesAccessTokenValidation(accessToken);
				System.out
						.println("Update profile---------------" + "            " + valid.getEmployee().getFirstName());
				if (valid != null) {
					boolean upstatus = empAuthServices.updateEmployees(employee, valid);
					if (upstatus) {
						status.put("status", "200: Successfull");
						status.put("message", "Employee Info Updated !");
					} else {
						status.put("status", "500: UnSuccessfull");
						status.put("message", "Server Error !");
					}
				} else {
					status.put("status", "401: UnAuthorized");
					status.put("message", "Access Token Ivalid !");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "500: UnSuccessfull");
			status.put("message", "Server Error !");
		}
		return status;
	}

	@RequestMapping(value = "/updateBankInfo", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<Object, Object> updateEmployeeBank(@RequestBody EmployeeBankUpdateRequest employee,
			@RequestHeader HttpHeaders headers) {
		Map<Object, Object> status = new HashMap<Object, Object>();
		Map<String, String> headerMap = null;

		try {
			headerMap = headers.toSingleValueMap();
			if (headerMap != null) {
				String accessToken = headerMap.get("access_token");
				EmployeesAuthentication valid = empAuthServices.employeesAccessTokenValidation(accessToken);
				if (valid != null) {
					boolean upstatus = empAuthServices.updateEmployeesBankInfo(employee, valid);
					if (upstatus) {
						status.put("status", "200: Successfull");
						status.put("message", "Employee BankInfo Updated !");
					} else {
						status.put("status", "500: UnSuccessfull");
						status.put("message", "Server Error !");
					}
				} else {
					status.put("status", "401: UnAuthorized");
					status.put("message", "Access Token Ivalid !");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			status.put("status", "500: UnSuccessfull");
			status.put("message", "Server Error !");
		}
		return status;
	}
}
