package com.intelizign.hire.dao;

import com.intelizign.hire.model.Admin;
import com.intelizign.hire.model.AdminAuthentication;
import com.intelizign.hire.model.Employee;
import com.intelizign.hire.model.Jobs;

public interface AdminDao {
	public boolean adminRegistration(Admin admin) throws Exception;
	public boolean emailUsernameCheck(String email,String username) throws Exception;
	public Admin  adminLogin(String emailusername,String username) throws Exception;
	public boolean generateUserAuth(AdminAuthentication admin) throws Exception;
	public boolean logoutAdmin(String accessToken ) throws Exception;
	public AdminAuthentication adminAccessTokenValidation(String accessToken) throws Exception;
	public boolean addEmployees(Employee employee) throws Exception;
	public boolean employeeEmailIdCheck(String email,String empId) throws Exception;
	public boolean addJobs(Jobs job) throws Exception;
}
