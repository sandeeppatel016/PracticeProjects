package com.intelizign.hire.util;
 

public interface EmailNotificationService {
	 String host = "smtp.gmail.com";
     String port = "587";
     String mailFrom = "sandeeppatidar016@gmail.com";
     String password = "Deeppatel016";
 
	public boolean sendEmailNotification(String receiveremail, String receivername, String email, String empId, String password) throws Exception;
}
