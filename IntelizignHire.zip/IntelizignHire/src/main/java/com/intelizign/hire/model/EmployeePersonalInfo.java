package com.intelizign.hire.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "employee_personal_info")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class EmployeePersonalInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2423940127057203395L;

	@Id
	@GeneratedValue
	@Column(name = "id")
	private long id;

	@Column(name = "father_name")
	private String fatherName;

	@Column(name = "mother_name")
	private String motherName;

	@Column(name = "nominee_name")
	private String nomineeName;

	@Column(name = "nominee_relation")
	private String nomineeRelation;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "father_dob")
	private Date fatherDob;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "mother_dob")
	private Date motherDob;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "employee_id")
	private Employee employee;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getNomineeName() {
		return nomineeName;
	}

	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}

	public String getNomineeRelation() {
		return nomineeRelation;
	}

	public void setNomineeRelation(String nomineeRelation) {
		this.nomineeRelation = nomineeRelation;
	}

	public Date getFatherDob() {
		return fatherDob;
	}

	public void setFatherDob(Date fatherDob) {
		this.fatherDob = fatherDob;
	}

	public Date getMotherDob() {
		return motherDob;
	}

	public void setMotherDob(Date motherDob) {
		this.motherDob = motherDob;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}
