package com.intelizign.hire.util;

import java.util.Date;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

 
public class EmailNotificationServiceImpl implements EmailNotificationService {

	@Override
	public boolean sendEmailNotification(String receiveremail, String receivername, String email, String empId,
			String password) throws Exception {
		// SMTP server information

		StringBuilder subject = new StringBuilder();
		subject.append("Welcome to the Intelizign :").append(receivername);
		// message contains HTML markups
		String message = "<i>Greetings!</i><br>";
		message += "<b>Wish you a nice day!</b><br>";
		message += "<font color=black>Here is your Intranet Access details:</font></br>";
		message += "<font color=red>Intelizign Email:</font>";
		message += "<font color=red>" + email + "</font></br>";
		message += "<font color=red>Employee Id:</font>";
		message += "<font color=red>" + empId + "</font></br>";
		message += "<font color=red>Password to access intranet and email:</font>";
		message += "<font color=red>" + password + "</font></br>";
		message += "<b>Please login to the portal and kindly update your profile information!</b><br>";
		message += "<b>Wish you a nice day!</b><br>";

		try {
			EmailNotificationServiceImpl.sendEmail(host, port, mailFrom, password, receiveremail, subject.toString(),
					message);
			System.out.println("Email sent.");
		} catch (Exception ex) {
			System.out.println("Failed to sent email.");
			ex.printStackTrace();
		}
		return true;
	}
	public static void sendEmail(String host, String port,
            final String userName, final String password, String toAddress,
            String subject, String message) throws AddressException,
            MessagingException {
 
        // sets SMTP server properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
 
        // creates a new session with an authenticator
        Authenticator auth = new Authenticator() {
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(userName, password);
            }
        };
 
        Session session = Session.getInstance(properties, auth);
 
        // creates a new e-mail message
        Message msg = new MimeMessage(session);
 
        msg.setFrom(new InternetAddress(userName));
        InternetAddress[] toAddresses = { new InternetAddress(toAddress) };
        msg.setRecipients(Message.RecipientType.TO, toAddresses);
        msg.setSubject(subject);
        msg.setSentDate(new Date());
        // set plain text message
        msg.setContent(message, "text/html");
 
        // sends the e-mail
        Transport.send(msg);
 
    }
}
